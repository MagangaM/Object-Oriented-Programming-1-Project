import javax.swing.*;
import java.io.*;
import java.time.LocalDate;
import java.util.*;

class Student implements Serializable {
    String name;
    String id;
    Map<String, Integer> subjects = new HashMap<>();

    public Student(String name, String id) {
        this.name = name;
        this.id = id;
    }

    public void addSubjectScore(String subject, int score) {
        subjects.put(subject, score);
    }

    public double calculateAverage() {
        int total = 0;
        for (int score : subjects.values()) {
            total += score;
        }
        return subjects.size() > 0 ? (double) total / subjects.size() : 0;
    }

    public String getGrade(double average) {
        if (average >= 70) return "A - Excellent";
        else if (average >= 60) return "B - Good";
        else if (average >= 50) return "C - Fair";
        else if (average >= 40) return "D - Poor";
        else return "E - Fail";
    }

    public String getRecommendation(double average) {
        if (average >= 70) return "Excellent";
        else if (average >= 60) return "Good";
        else if (average >= 50) return "Fair";
        else return "Poor";
    }

    public String generateReport() {
        double average = calculateAverage();
        StringBuilder sb = new StringBuilder();
        sb.append("Report Card\n==============\n");
        sb.append("Name: " + name + "\n");
        sb.append("ID: " + id + "\n");
        sb.append("Subjects and Scores:\n");
        for (Map.Entry<String, Integer> entry : subjects.entrySet()) {
            sb.append(entry.getKey() + ": " + entry.getValue() + "\n");
        }
        sb.append("Average Score: " + average + "\n");
        sb.append("Grade: " + getGrade(average) + "\n");
        sb.append("Recommendation: " + getRecommendation(average) + "\n");
        sb.append("Date Viewed: " + LocalDate.now() + "\n\n");
        return sb.toString();
    }
}

public class ExamProcessingSystemGUI {
    private static final List<Student> students = new ArrayList<>();
    private static int studentCount = 0;

    public static void saveToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("students.dat"))) {
            oos.writeObject(students);
            JOptionPane.showMessageDialog(null, "Data saved to students.dat");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public static void loadFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.dat"))) {
            List<Student> loadedStudents = (List<Student>) ois.readObject();
            StringBuilder reports = new StringBuilder();
            for (Student s : loadedStudents) {
                reports.append(s.generateReport());
            }
            JTextArea reportArea = new JTextArea(reports.toString());
            JScrollPane scrollPane = new JScrollPane(reportArea);
            JOptionPane.showMessageDialog(null, scrollPane, "Loaded Students", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Failed to load data.");
            e.printStackTrace();
        }
    }

    public static void exportToTextFile() {
        try (PrintWriter writer = new PrintWriter("students_report.txt")) {
            for (Student s : students) {
                writer.println(s.generateReport());
            }
            JOptionPane.showMessageDialog(null, "Data exported to students_report.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void createGUI() {
        JFrame frame = new JFrame("Examination Processing System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 600);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JTextField nameField = new JTextField(20);
        JTextField idField = new JTextField(20);
        JTextField[] subjectFields = new JTextField[5];
        JTextField[] scoreFields = new JTextField[5];

        panel.add(new JLabel("Enter Student Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Enter Student ID:"));
        panel.add(idField);

        for (int i = 0; i < 5; i++) {
            subjectFields[i] = new JTextField(10);
            scoreFields[i] = new JTextField(5);
            panel.add(new JLabel("Subject " + (i + 1) + ":"));
            panel.add(subjectFields[i]);
            panel.add(new JLabel("Score:"));
            panel.add(scoreFields[i]);
        }

        JButton submitBtn = new JButton("Submit Student");
        JButton reportBtn = new JButton("Show Reports");
        JButton loadBtn = new JButton("Load Saved Students");
        JButton exportBtn = new JButton("Export to Text File");

        JTextArea reportArea = new JTextArea(20, 40);
        reportArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(reportArea);

        submitBtn.addActionListener(e -> {
            String name = nameField.getText();
            String id = idField.getText();
            Student student = new Student(name, id);
            for (int i = 0; i < 5; i++) {
                String subject = subjectFields[i].getText();
                int score;
                try {
                    score = Integer.parseInt(scoreFields[i].getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid score input.");
                    return;
                }
                student.addSubjectScore(subject, score);
            }
            students.add(student);
            studentCount++;
            if (studentCount >= 10) {
                JOptionPane.showMessageDialog(frame, "10 students entered. Please view the reports.");
            } else {
                JOptionPane.showMessageDialog(frame, "Student added successfully.");
            }
        });

        reportBtn.addActionListener(e -> {
            StringBuilder reports = new StringBuilder();
            for (Student student : students) {
                reports.append(student.generateReport());
            }
            reportArea.setText(reports.toString());
            saveToFile();
        });

        loadBtn.addActionListener(e -> loadFromFile());
        exportBtn.addActionListener(e -> exportToTextFile());

        panel.add(submitBtn);
        panel.add(reportBtn);
        panel.add(loadBtn);
        panel.add(exportBtn);
        panel.add(scrollPane);

        frame.add(panel);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ExamProcessingSystemGUI::createGUI);
    }
}
